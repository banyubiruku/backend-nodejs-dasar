
import {writeToFile} from "./write.js";

writeToFile("hello.log", "Eko Kurniawan Khannedy");

console.info("Hello World");
