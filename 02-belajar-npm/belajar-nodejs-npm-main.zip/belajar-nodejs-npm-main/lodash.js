import _ from "lodash";

const name = "EKO KURNIAWAN KHANNEDY";
const result = _.capitalize(name);

console.info(result);
