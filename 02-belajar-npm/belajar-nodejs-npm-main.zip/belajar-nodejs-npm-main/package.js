import {sayHello, sum} from "belajar-nodejs-npm-library-khannedy";
import {max, min} from "belajar-nodejs-npm-library-khannedy/number";

console.info(sayHello("Eko"));

console.info(sum([10, 10, 10, 10, 10]));

console.info(min(10, 20));
console.info(max(10, 20));
