import {writeToFile} from "belajar-nodejs-npm/write";

writeToFile("export.log", "Belajar Export");
